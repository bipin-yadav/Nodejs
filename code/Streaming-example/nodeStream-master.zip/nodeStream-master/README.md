# nodeStream
Streaming from ffmpeg to HTML5 canvas.

more info: http://go.yuri.at/streaming-ffmpeg-with-nodejs-on-web-sockets-to-html/
