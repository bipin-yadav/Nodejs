# streamServer

**Author:** Gerald Kogler, Sergi Lario

**Overview:** Streaming from ffmpeg to HTML5 canvas.


### How to Use streamServer

run:

```js
npm install
```

